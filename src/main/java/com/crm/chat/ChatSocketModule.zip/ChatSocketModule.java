package com.crm.chat;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.corundumstudio.socketio.SocketIOClient;
import com.corundumstudio.socketio.annotation.OnEvent;
import com.crm.user.UserServiceException;

@Component
public class ChatSocketModule {

    @Autowired
    private ChatsService chatsService;

    @OnEvent("addChat")
    public void handleAddChat(SocketIOClient client, Chats chat) {
        try {
            Chats savedChat = chatsService.addChats(chat).getBody();
            Long supportId = savedChat.getSupportId();

            client.getNamespace().getRoomOperations(String.valueOf(supportId))
                .sendEvent("chatAdded", savedChat);
        } catch (UserServiceException e) {
            client.sendEvent("chatError", e.getMessage());
        }
    }

    @OnEvent("getChatsBySupportId")
    public void handleGetChats(SocketIOClient client, Long supportId) {
        try {
            client.joinRoom(String.valueOf(supportId));
            List<Map<String, Object>> chats = chatsService.getChatsBySupportId(supportId);
            client.sendEvent("chatList", chats);
        } catch (UserServiceException e) {
            client.sendEvent("chatError", e.getMessage());
        }
    }
}
