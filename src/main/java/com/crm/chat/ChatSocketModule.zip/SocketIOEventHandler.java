package com.crm.chat;

import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.corundumstudio.socketio.SocketIOServer;
import com.crm.notifications.NotificationsRepository;
import com.crm.user.UserRepository;
import com.crm.user.UserServiceException;

@Component
public class SocketIOEventHandler {

	@Autowired
	private ChatsService chatsService;

	@Autowired
	private NotificationsRepository notificationsRepo;

	@Autowired
	private UserRepository userRepo;

	@Autowired
	public SocketIOEventHandler(SocketIOServer server) {

		server.addEventListener("addChat", Chats.class, (client, chat, ackSender) -> {
			try {
				Chats newChat = chatsService.addChats(chat).getBody();
				long supportId = newChat.getSupportId();
				server.getBroadcastOperations().sendEvent("chat-" + supportId, newChat);
			} catch (UserServiceException e) {
				server.getBroadcastOperations().sendEvent("chat-error-" + chat.getSupportId(), e.getMessage());
			}
		});

		server.addEventListener("getChatsBySupportId", Chats.class, (client, chat, ackSender) -> {
			long supportId = chat.getSupportId();
			List<Map<String, Object>> chats = chatsService.getChatsBySupportId(supportId);
			client.sendEvent("chat-" + supportId, chats);
		});
	}
}
