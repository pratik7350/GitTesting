package com.crm.project;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import com.crm.Exception.Error;
import com.crm.security.JwtUtil;
import com.crm.user.UserServiceException;
import jakarta.servlet.http.HttpServletResponse;

@Service
public class ProjectDetailsService {

	@Autowired
	private JwtUtil jwtUtil;

	@Autowired
	private ProjectDetailsRepository projectDetailsRepo;

	public ResponseEntity<?> createProjectDetails(String token, ProjectDetails details, long userId) {
		try {

			if (jwtUtil.isTokenExpired(token)) {
				return ResponseEntity.status(HttpServletResponse.SC_UNAUTHORIZED)
						.body("Unauthorized: Your session has expired.");
			}

			String role = jwtUtil.extractRole(token);

			if (!"ADMIN".equalsIgnoreCase(role)) {
				return ResponseEntity.status(HttpServletResponse.SC_FORBIDDEN)
						.body("Forbidden: You do not have the necessary permissions.");
			}
			details.setUserId(userId);
			details.setCreatedOn(System.currentTimeMillis());
			ProjectDetails projectDetails = projectDetailsRepo.save(details);
			return ResponseEntity.ok(projectDetails);
		} catch (UserServiceException e) {
			return ResponseEntity.status(e.getStatusCode()).body(new Error(e.getStatusCode(), e.getMessage(),
					"Unable to register user", System.currentTimeMillis()));
		} catch (Exception ex) {
			throw new UserServiceException(409, "Invalid Credentials ");
		}
	}

	public ResponseEntity<?> getDeatilsByProjectId(long projectId) {
		try {
			Optional<ProjectDetails> byId = projectDetailsRepo.findById(projectId);
			return ResponseEntity.ok(byId);

		} catch (UserServiceException e) {
			return ResponseEntity.status(e.getStatusCode()).body(new Error(e.getStatusCode(), e.getMessage(),
					"Unable to register user", System.currentTimeMillis()));
		} catch (Exception ex) {
			throw new UserServiceException(409, "Invalid Credentials ");
		}

	}

	public ResponseEntity<?> getDeatilsByProjectId(long userId, long projectId) {
		try {
			Optional<ProjectDetails> byId = projectDetailsRepo.findByUserIdAndId(userId, projectId);
			return ResponseEntity.ok(byId);

		} catch (UserServiceException e) {
			return ResponseEntity.status(e.getStatusCode()).body(new Error(e.getStatusCode(), e.getMessage(),
					"Unable to register user", System.currentTimeMillis()));
		} catch (Exception ex) {
			throw new UserServiceException(409, "Invalid Credentials ");
		}

	}

	public ResponseEntity<?> getTowerDetails(String propertyName, String towerName) {
		try {
			Optional<ProjectDetails> projectDetailsOpt = projectDetailsRepo.findByPropertyName(propertyName);

			if (projectDetailsOpt.isPresent()) {
				ProjectDetails project = projectDetailsOpt.get();

				if (!project.getTowers().contains(towerName)) {
					return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Tower not found in this property");
				}

				List<List<String>> floorsWithFlats = new ArrayList<>();

				for (int floorNum = project.getTotalFloors(); floorNum >= 1; floorNum--) {
					final String floorPrefix = String.valueOf(floorNum);
					List<String> flatsOnFloor = project.getFlats().stream().filter(flat -> flat.startsWith(floorPrefix))
							.sorted().collect(Collectors.toList());

					if (!flatsOnFloor.isEmpty()) {
						floorsWithFlats.add(flatsOnFloor);
					}
				}
				Map<String, Object> response = new HashMap<>();
				response.put("propertyName", propertyName);
				response.put("tower", towerName);
				response.put("floors", floorsWithFlats);
				return ResponseEntity.ok(response);
			}
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Property not found");
		} catch (UserServiceException e) {
			return ResponseEntity.status(e.getStatusCode()).body(new Error(e.getStatusCode(), e.getMessage(),
					"Unable to register user", System.currentTimeMillis()));
		} catch (Exception ex) {
			throw new UserServiceException(409, "Invalid Credentials ");
		}
	}

}
