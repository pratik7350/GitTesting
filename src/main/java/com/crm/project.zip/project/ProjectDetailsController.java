package com.crm.project;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.crm.Exception.Error;
import com.crm.user.UserServiceException;

@RestController
@RequestMapping("/api/project")
public class ProjectDetailsController {

	@Autowired
	public ProjectDetailsRepository detailsRepository;

	@Autowired
	ProjectDetailsService detailsService;

	@PostMapping("/createProject/{userId}")
	public ResponseEntity<?> createProject(@CookieValue(value = "token", required = true) String token,
			@RequestBody ProjectDetails details, @PathVariable long userId) {
		try {

			return detailsService.createProjectDetails(token, details, userId);
		} catch (UserServiceException e) {
			return ResponseEntity.status(e.getStatusCode()).body(
					new Error(e.getStatusCode(), e.getMessage(), "Unable to add data", System.currentTimeMillis()));
		}

	}

	@GetMapping("/getProjectById/{projectId}")
	public ResponseEntity<?> getProjectByItsId(@PathVariable long projectId) {
		try {
			return detailsService.getDeatilsByProjectId(projectId);
		} catch (UserServiceException e) {
			return ResponseEntity.status(e.getStatusCode()).body(
					new Error(e.getStatusCode(), e.getMessage(), "Unable to add data", System.currentTimeMillis()));
		}

	}

	@GetMapping("/getProjectByUserIdAndId/{userId}/{projectId}")
	public ResponseEntity<?> getProjectByUserIdAndItsId(@PathVariable long userId, @PathVariable long projectId) {
		try {
			return detailsService.getDeatilsByProjectId(userId, projectId);
		} catch (UserServiceException e) {
			return ResponseEntity.status(e.getStatusCode()).body(
					new Error(e.getStatusCode(), e.getMessage(), "Unable to add data", System.currentTimeMillis()));
		}

	}

	@GetMapping("/getTowerDetails/{propertyName}/{towerName}")
	public ResponseEntity<?> getTowerDetails(@PathVariable String propertyName, @PathVariable String towerName) {
		try {
			return detailsService.getTowerDetails(propertyName, towerName);
		}
		catch (UserServiceException e) {
			return ResponseEntity.status(e.getStatusCode()).body(
					new Error(e.getStatusCode(), e.getMessage(), "Unable to add data", System.currentTimeMillis()));
		}
	}

}
