package com.crm.project;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.crm.security.JwtUtil;

import jakarta.servlet.http.HttpServletResponse;

@Service
public class ProjectDetailsService {

    @Autowired
    private JwtUtil jwtUtil;

    @Autowired
    private ProjectDetailsRepository projectDetailsRepo;

    @Autowired
    private TowerDetailsRepository towerDetailsRepo;

    @Autowired
    private FloorDetailsRepository floorDetailsRepo;

    @Autowired
    private FlatRepository flatRepo;

    @Transactional
    public ResponseEntity<?> createProjectDetails(String token, ProjectDetails details, long userId) {
        try {
            if (jwtUtil.isTokenExpired(token)) {
                return ResponseEntity.status(HttpServletResponse.SC_UNAUTHORIZED)
                        .body("Unauthorized: Your session has expired.");
            }

            String role = jwtUtil.extractRole(token);

            if (!"ADMIN".equalsIgnoreCase(role)) {
                return ResponseEntity.status(HttpServletResponse.SC_FORBIDDEN)
                        .body("Forbidden: You do not have the necessary permissions.");
            }

            details.setUserId(userId);
            details.setCreatedOn(System.currentTimeMillis());
            ProjectDetails projectDetails = projectDetailsRepo.save(details);
            return ResponseEntity.ok(projectDetails);
        } catch (Exception ex) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to create project details.");
        }
    }

    public ResponseEntity<?> getProjectDetailsById(long projectId) {
        try {
            Optional<ProjectDetails> projectDetailsOpt = projectDetailsRepo.findById(projectId);
            return projectDetailsOpt.map(ResponseEntity::ok)
                    .orElseGet(() -> ResponseEntity.status(HttpStatus.NOT_FOUND).body("Project not found"));
        } catch (Exception ex) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to retrieve project details.");
        }
    }

    public ResponseEntity<?> createTowerDetails(TowerDetails towerDetails) {
        try {
            towerDetailsRepo.save(towerDetails);
            return ResponseEntity.ok("Tower details saved successfully");
        } catch (Exception ex) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to save tower details.");
        }
    }

    public ResponseEntity<?> createFloorDetails(FloorDetails floorDetails) {
        try {
            floorDetailsRepo.save(floorDetails);
            return ResponseEntity.ok("Floor details saved successfully");
        } catch (Exception ex) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to save floor details.");
        }
    }

    public ResponseEntity<?> createFlat(Flat flat) {
        try {
            flatRepo.save(flat);
            return ResponseEntity.ok("Flat details saved successfully");
        } catch (Exception ex) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to save flat details.");
        }
    }

}
