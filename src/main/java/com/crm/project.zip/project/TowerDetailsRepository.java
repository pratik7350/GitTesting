package com.crm.project;

import org.springframework.data.jpa.repository.JpaRepository;

public interface TowerDetailsRepository extends JpaRepository<TowerDetails, Long>{

}
