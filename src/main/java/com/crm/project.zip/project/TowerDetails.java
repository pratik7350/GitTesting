package com.crm.project;

import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name = "tower_details")
public class TowerDetails {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;

	private String towerName;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "project_id")
	private ProjectDetails project;

	@OneToMany(mappedBy = "tower", cascade = CascadeType.ALL, orphanRemoval = true)
	private List<FloorDetails> floors = new ArrayList<>();

	public long getId() {
		return id;
	}

	public String getTowerName() {
		return towerName;
	}

	public ProjectDetails getProject() {
		return project;
	}

	public List<FloorDetails> getFloors() {
		return floors;
	}

	public void setId(long id) {
		this.id = id;
	}

	public void setTowerName(String towerName) {
		this.towerName = towerName;
	}

	public void setProject(ProjectDetails project) {
		this.project = project;
	}

	public void setFloors(List<FloorDetails> floors) {
		this.floors = floors;
	}

	public TowerDetails() {}
	
	public TowerDetails(long id, String towerName, ProjectDetails project, List<FloorDetails> floors) {
		super();
		this.id = id;
		this.towerName = towerName;
		this.project = project;
		this.floors = floors;
	}

	@Override
	public String toString() {
		return "TowerDetails [id=" + id + ", towerName=" + towerName + ", project=" + project + ", floors=" + floors
				+ "]";
	}

}
